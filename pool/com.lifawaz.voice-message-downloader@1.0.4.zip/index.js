(() => {
  'use strict';

  const DEFAULT_SETTINGS = Object.freeze({
    storageDir: 'documents',
    folder: 'voice-messages',
  });
  const IS_VOICE_MESSAGE = 1 << 13;
  const DISCORD_ATTACHMENT_URL = /^https:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net)\/(?:attachments|ephemeral-attachments)\//i;
  const MAX_AUDIO_BYTES = 50 * 1024 * 1024;

  function errorText(error) {
    return error && typeof error.message === 'string' ? error.message : String(error);
  }

  function normalizeStorageDir(value) {
    return value === 'cache' ? 'cache' : 'documents';
  }

  function normalizeFolder(value) {
    const parts = String(value || DEFAULT_SETTINGS.folder)
      .replace(/\\/g, '/')
      .split('/')
      .map(part => part.trim())
      .filter(part => part && part !== '.' && part !== '..')
      .map(part => part.replace(/[^a-zA-Z0-9 _.-]/g, '_').replace(/^\.+$/, '').slice(0, 48))
      .filter(Boolean)
      .slice(0, 6);
    return parts.length ? parts.join('/') : DEFAULT_SETTINGS.folder;
  }

  function normalizeSettings(settings) {
    return {
      storageDir: normalizeStorageDir(settings && settings.storageDir),
      folder: normalizeFolder(settings && settings.folder),
    };
  }

  function getVoiceAttachment(message) {
    if (!message || typeof message.flags !== 'number') return undefined;
    if ((message.flags & IS_VOICE_MESSAGE) === 0) return undefined;
    if (!Array.isArray(message.attachments) || message.attachments.length !== 1) return undefined;

    const attachment = message.attachments[0];
    if (!attachment || typeof attachment.content_type !== 'string') return undefined;
    if (!attachment.content_type.toLowerCase().startsWith('audio/')) return undefined;

    const url = attachment.url || attachment.proxy_url;
    if (typeof url !== 'string' || !DISCORD_ATTACHMENT_URL.test(url)) return undefined;
    return attachment;
  }

  function getMessageFromProps(props) {
    const candidate = props?.message
      ?? props?.messageRecord?.message
      ?? props?.record?.message
      ?? props?.item?.message;
    if (candidate?.message && typeof candidate.flags !== 'number') return candidate.message;
    return candidate;
  }

  function findActionSheet(element, ActionSheet, seen = new Set()) {
    if (!element || typeof element !== 'object' || seen.has(element)) return undefined;
    seen.add(element);

    if (Array.isArray(element)) {
      for (const child of element) {
        const found = findActionSheet(child, ActionSheet, seen);
        if (found) return found;
      }
      return undefined;
    }

    const node = element;
    if (node.type === ActionSheet || node.type?.displayName === 'ActionSheet' || node.type?.name === 'ActionSheet') {
      return node;
    }
    return findActionSheet(node.props?.children, ActionSheet, seen);
  }

  function addToActionSheet(tree, group, ActionSheet) {
    const sheet = findActionSheet(tree, ActionSheet);
    if (!sheet) return false;

    const children = [sheet.props?.children].flat().filter(Boolean);
    children.push(group);
    sheet.props = { ...sheet.props, children };
    return true;
  }

  function getFileName(attachment, messageId) {
    const raw = typeof attachment.filename === 'string' ? attachment.filename : '';
    let name = raw.replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').trim();
    if (!name) name = `voice-message-${messageId || Date.now()}.ogg`;
    if (!/\.[a-z0-9]{2,8}$/i.test(name)) name += '.ogg';

    const dot = name.lastIndexOf('.');
    const stem = dot > 0 ? name.slice(0, dot) : name;
    const extension = dot > 0 ? name.slice(dot) : '.ogg';
    const idSuffix = messageId ? String(messageId).replace(/[^a-zA-Z0-9_-]/g, '').slice(-10) : 'audio';
    return `${stem}-${idSuffix || 'audio'}-${Date.now()}${extension}`;
  }

  function arrayBufferToBase64(buffer) {
    const bytes = new Uint8Array(buffer);
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    let output = '';

    for (let i = 0; i < bytes.length; i += 3) {
      const a = bytes[i];
      const hasB = i + 1 < bytes.length;
      const hasC = i + 2 < bytes.length;
      const b = hasB ? bytes[i + 1] : 0;
      const c = hasC ? bytes[i + 2] : 0;
      output += alphabet[a >> 2];
      output += alphabet[((a & 3) << 4) | (b >> 4)];
      output += hasB ? alphabet[((b & 15) << 2) | (c >> 6)] : '=';
      output += hasC ? alphabet[c & 63] : '=';
    }

    return output;
  }

  async function fetchAudioAsBase64(url, attachment) {
    let response;
    try {
      response = await fetch(url, { method: 'GET' });
    } catch (error) {
      throw new Error(`Could not contact Discord's attachment server: ${errorText(error)}`);
    }

    if (!response || !response.ok) {
      const status = response ? `${response.status} ${response.statusText || ''}`.trim() : 'no response';
      throw new Error(`Discord's attachment server returned ${status}. The voice-message link may have expired.`);
    }

    const contentType = String(response.headers?.get?.('content-type') || attachment.content_type || '').toLowerCase();
    if (contentType && !contentType.startsWith('audio/') && !contentType.includes('application/octet-stream')) {
      throw new Error(`The attachment server returned an unexpected content type: ${contentType}`);
    }

    const buffer = await response.arrayBuffer();
    if (!buffer || buffer.byteLength === 0) throw new Error('Discord returned an empty audio file.');
    if (buffer.byteLength > MAX_AUDIO_BYTES) {
      throw new Error(`The audio file is larger than the ${Math.round(MAX_AUDIO_BYTES / 1024 / 1024)} MB safety limit.`);
    }

    return arrayBufferToBase64(buffer);
  }

  async function saveVoiceMessage(files, attachment, messageId, settings) {
    const url = attachment.url || attachment.proxy_url;
    if (!url || !DISCORD_ATTACHMENT_URL.test(url)) {
      throw new Error('The voice attachment URL is missing or unsupported.');
    }

    // Remote downloads use fetch(); FileModule.readAsset() can interpret CDN URLs
    // as Android resources on some builds and throw Resource id #0x0.
    const base64 = await fetchAudioAsBase64(url, attachment);
    const config = normalizeSettings(settings);
    const filename = getFileName(attachment, messageId);
    const relativePath = `${config.folder}/${filename}`;

    if (!files || typeof files.writeFile !== 'function') {
      throw new Error('Valenced FileModule.writeFile is unavailable in this build.');
    }

    let savedPath;
    try {
      savedPath = await files.writeFile(config.storageDir, relativePath, base64, 'base64');
    } catch (error) {
      throw new Error(`Audio downloaded, but Android could not write it to ${config.storageDir}: ${errorText(error)}`);
    }

    if (typeof savedPath !== 'string' || !savedPath) {
      throw new Error('Android did not return a saved file path after writing the audio.');
    }
    return { savedPath, config };
  }

  function SettingsComponent({ api }) {
    const settings = normalizeSettings({
      ...DEFAULT_SETTINGS,
      ...(api.jsonStorage.use() || {}),
    });
    const Design = valenced.discord.design.Design;
    const createElement = valenced.react.React.createElement;

    return createElement(
      Design.Stack,
      { spacing: 20 },
      createElement(
        Design.TableRadioGroup,
        {
          title: 'Save location',
          value: settings.storageDir,
          onChange: storageDir => api.jsonStorage.set({ storageDir: normalizeStorageDir(storageDir) }),
        },
        createElement(Design.TableRadioRow, {
          label: 'Documents',
          subLabel: 'Recommended. Files stay in Valenced app storage.',
          value: 'documents',
        }),
        createElement(Design.TableRadioRow, {
          label: 'Cache',
          subLabel: 'Temporary storage. Android or Valenced may clear these files.',
          value: 'cache',
        }),
      ),
      createElement(
        Design.TableRowGroup,
        { title: 'Folder name' },
        createElement(Design.TextInput, {
          label: 'Folder inside the selected location',
          value: settings.folder,
          maxLength: 120,
          placeholder: 'voice-messages',
          description: 'You can use subfolders, for example Audio/Discord. Parent-folder paths are ignored.',
          onChange: folder => api.jsonStorage.set({ folder }),
        }),
      ),
      createElement(
        Design.Text,
        { variant: 'text-sm/normal' },
        'The selected location is inside Valenced app storage. This version cannot write directly to the public Android Downloads folder because Valenced exposes only Documents and Cache through its file API.',
      ),
    );
  }

  const options = plugin({
    jsonStorage: {
      load: true,
      default: DEFAULT_SETTINGS,
    },
    start({ cleanup, plugin: pluginApi, jsonStorage, unscoped }) {
      const { getModules } = unscoped.modules.finders;
      const { withName } = unscoped.modules.finders.filters;
      const { instead } = unscoped.patcher;
      const { ActionSheetActionCreators } = unscoped.discord.actions;
      const { ActionSheet, ActionSheetRow } = unscoped.discord.design.Design;
      const files = unscoped.discord.native.FileModule;
      const { lookupGeneratedIconComponent } = unscoped.utils.discord;
      const { createElement } = unscoped.react.React;

      cleanup(getModules(withName('LongPressMessageActionSheet'), mod => {
        if (typeof mod?.default !== 'function') return;

        cleanup(instead(mod, 'default', (args, Original) => {
          const tree = Reflect.apply(Original, undefined, args);

          try {
            const message = getMessageFromProps(args?.[0]);
            const attachment = getVoiceAttachment(message);
            if (!attachment) return tree;

            const filename = getFileName(attachment, message?.id);
            const group = createElement(
              ActionSheetRow.Group,
              null,
              createElement(ActionSheetRow, {
                label: 'Download Voice Message',
                icon: createElement(ActionSheetRow.Icon, {
                  IconComponent: lookupGeneratedIconComponent('DownloadIcon'),
                }),
                onPress: async () => {
                  try {
                    ActionSheetActionCreators.hideActionSheet();
                    const settings = normalizeSettings(jsonStorage.cache || DEFAULT_SETTINGS);
                    const result = await saveVoiceMessage(files, attachment, message?.id, settings);
                    alert(`Voice message saved successfully.\n\n${result.savedPath}`);
                  } catch (error) {
                    const detail = errorText(error);
                    pluginApi.reportError(`Voice message download failed: ${detail}`);
                    alert(`Could not save ${filename}.\n\n${detail}\n\nCheck Valenced Debug Logs for details.`);
                  }
                },
              }),
            );

            if (!addToActionSheet(tree, group, ActionSheet)) {
              pluginApi.reportError('Voice message was detected, but the long-press action sheet could not be located.');
            }
          } catch (error) {
            pluginApi.reportError(`Could not add voice message download action: ${errorText(error)}`);
          }

          return tree;
        }));
      }, { returnNamespace: true }));
    },
    SettingsComponent,
  });

  return { default: options };
})()
